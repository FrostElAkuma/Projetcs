-- Keep a log of any SQL queries you execute as you solve the mystery.

-- Ran .schema to see all tables and their contents
.schema

--Seems like the best thing to do to get more info on the theft
SELECT description FROM crime_scene_reports WHERE month = 7 AND day = 28 AND street = "Chamberlin Street";

--Checking the transcripts of the witnesses
SELECT transcript FROM interviews WHERE transcript LIKE "%courthouse%";
SELECT * FROM interviews WHERE transcript LIKE "%courthouse%";

--Based on info from witnesses
SELECT license_plate FROM courthouse_security_logs WHERE activity = "exit" AND year = 2020 AND month = 7 AND day = 28 AND hour = 10 AND minute > 15 AND minute < 25;
SELECT account_number FROM atm_transactions WHERE transaction_type = "withdraw" AND year = 2020 AND month = 7 AND day = 28 AND atm_location = "Fifer Street";

--Based in the atm transaction history
SELECT person_id, creation_year FROM bank_accounts WHERE account_number IN(SELECT account_number FROM atm_transactions WHERE transaction_type = "withdraw" AND year = 2020 AND month = 7 AND day = 28 AND atm_location = "Fifer Street");

--checking airports and flights based on information
SELECT * FROM airports;
SELECT id, destination_airport_id, hour, minute FROM flights WHERE year = 2020 AND month = 7 AND day = 29 AND origin_airport_id = 8;
SELECT passport_number, seat FROM passengers WHERE flight_id = 36;

--Checking phone calls based on information from witnesses
SELECT caller, receiver FROM phone_calls WHERE year = 2020 AND month = 7 AND day =28 AND duration < 60;

--Final filtering
SELECT name FROM people WHERE phone_number IN(SELECT caller FROM phone_calls WHERE year = 2020 AND month = 7 AND day =28 AND duration < 60) AND passport_number IN(SELECT passport_number FROM passengers WHERE flight_id = 36) AND license_plate IN(SELECT license_plate FROM courthouse_security_logs WHERE activity = "exit" AND year = 2020 AND month = 7 AND day = 28 AND hour = 10 AND minute > 15 AND minute < 25);
SELECT * FROM people WHERE name = "Ernest";
SELECT * FROM people WHERE phone_number = "(375) 555-8161";