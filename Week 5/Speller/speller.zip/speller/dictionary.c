// Implements a dictionary's functionality

#include <stdbool.h>

#include "dictionary.h"

//Dictionaries i added
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

//Global var i added for size cuz my brain thinks this is easeir
int si = 0;

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
const unsigned int N = 380;

// Hash table
node *table[N];

// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    //Got this popular hash function and edited it a bit from https://stackoverflow.com/questions/7700400/whats-a-good-hash-function-for-english-words
    int hashNum = hash(word);

    for (node *tmp = table[hashNum]; tmp != NULL; tmp = tmp->next)
    {
        if (strcasecmp(word, tmp->word) == 0)
        {
            return true;
        }
    }


    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    unsigned long hash = 5381;
    int c, n;

    c = tolower(*word++);

    while (c != '\0')
    {
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
        c = tolower(*word++);
    }

    n = hash % 380;

    return n;
}

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
    FILE *input = fopen(dictionary, "r");
    if (input == NULL)
    {
        printf("Could not open file.\n");
        return false;
    }

    // An array if chars aka a string
    /*char *word1 = malloc(45 * sizeof(char));

    if (word1 == NULL)
    {
        printf("No space ? \n");
        free(word1);
        return false;
    }*/

    char word1[LENGTH + 1];

    while (fscanf(input, "%s", word1) != EOF)
    {
        int hashNum = hash(word1);

        node *n = malloc(sizeof(node));
        if (n == NULL)
        {
            return false;
        }

        strcpy (n->word, word1);
        n->next = table[hashNum];
        table[hashNum] = n;

        si++;
    }

    fclose(input);

    return true;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{

    return si;
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    for (int i = 0; i < N; i++)
    {
         while (table[i] != NULL)
        {
            node *tmp = table[i]->next;  // a temporary pointer that saves the value of the next node
            free(table[i]);  //We free the current table
            table[i] = tmp;  //We update the table to be that next pointer we saved at the beginning
        }
    }
    return true;
}