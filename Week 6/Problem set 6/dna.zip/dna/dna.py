import sys
import csv
# my code could be more pythonic and DRY but needs more time so maybe later
def main():
    if len(sys.argv) != 3:
        print("missing command-line arguement beep boop")

    small = []
    if sys.argv[1] == "databases/small.csv":
        with open(sys.argv[1], "r") as file1:
                reader = csv.DictReader(file1)
                for row in reader:
                    row["AGATC"] = int(row["AGATC"])
                    row["AATG"] = int(row["AATG"])
                    row["TATC"] = int(row["TATC"])
                    #row["TTTTTTCT"] = int(row["TTTTTTCT"])
                    #row["TCTAG"] = int(row["TCTAG"])
                    #row["GATA"] = int(row["GATA"])
                    #row["GAAA"] = int(row["GAAA"])
                    #row["TCTG"] = int(row["TCTG"])
                    small.append(row)
                    x = 1

    else:
        with open(sys.argv[1], "r") as file1:
                reader = csv.DictReader(file1)
                for row in reader:
                    row["AGATC"] = int(row["AGATC"])
                    row["AATG"] = int(row["AATG"])
                    row["TATC"] = int(row["TATC"])
                    row["TTTTTTCT"] = int(row["TTTTTTCT"])
                    row["TCTAG"] = int(row["TCTAG"])
                    row["GATA"] = int(row["GATA"])
                    row["GAAA"] = int(row["GAAA"])
                    row["TCTG"] = int(row["TCTG"])
                    small.append(row)
                    x = 2


    file2 = open(sys.argv[2], "r")
    for line in file2:
        dna = line
    file2.close()


    positionAGATC = []
    positionAATG = []
    positionTATC = []
    positionTTTTTTCT = []
    positionTCTAG = []
    positionGATA = []
    positionGAAA = []
    positionTCTG = []

    #getting the positions for each correct str
    for i in range(0, len(dna)-3, 1): #subtracted 3 cuz we cant have a proper str in the last 3 letters and it gives me an error if i dont subtract since we will be going out of bounds
        if dna[i] == "A" and dna[i+1] == "G" and dna[i+2] == "A" and dna[i+3] == "T" and dna[i+4] == "C":
            positionAGATC.append(i)

        elif dna[i] == "A" and dna[i+1] == "A" and dna[i+2] == "T" and dna[i+3] == "G":
            positionAATG.append(i)

        elif dna[i] == "T" and dna[i+1] == "A" and dna[i+2] == "T" and dna[i+3] == "C":
            positionTATC.append(i)

        elif dna[i] == "T" and dna[i+1] == "T" and dna[i+2] == "T" and dna[i+3] == "T" and dna[i+4] == "T" and dna[i+5] == "T" and dna[i+6] == "C" and dna[i+7] == "T":
            positionTTTTTTCT.append(i)

        elif dna[i] == "T" and dna[i+1] == "C" and dna[i+2] == "T" and dna[i+3] == "A" and dna[i+4] == "G":
            positionTCTAG.append(i)

        elif dna[i] == "G" and dna[i+1] == "A" and dna[i+2] == "T" and dna[i+3] == "A":
            positionGATA.append(i)

        elif dna[i] == "G" and dna[i+1] == "A" and dna[i+2] == "A" and dna[i+3] == "A":
            positionGAAA.append(i)

        elif dna[i] == "T" and dna[i+1] == "C" and dna[i+2] == "T" and dna[i+3] == "G":
            positionTCTG.append(i)


    maxAGATC = streak(positionAGATC, dna)
    maxAATG = streak(positionAATG, dna)
    maxTATC = streak(positionTATC, dna)
    maxTTTTTTCT = streak(positionTTTTTTCT, dna)
    maxTCTAG = streak(positionTCTAG, dna)
    maxGATA = streak(positionGATA, dna)
    maxGAAA = streak(positionGAAA, dna)
    maxTCTG = streak(positionTCTG, dna)

    #print(maxTTTTTTCT) used for debugging
    #print(positionAGATC)

    boo = True

    for i in range(0, len(small), 1):
        if x == 1:
            if maxAGATC == small[i]["AGATC"] and maxAATG == small[i]["AATG"] and maxTATC == small[i]["TATC"]:
                print(small[i]["name"])
                boo = False

        if x == 2:
            if maxAGATC == small[i]["AGATC"] and maxAATG == small[i]["AATG"] and maxTATC == small[i]["TATC"] and maxTTTTTTCT == small[i]["TTTTTTCT"] and maxTCTAG == small[i]["TCTAG"] and maxGATA == small[i]["GATA"] and maxGAAA == small[i]["GAAA"] and maxTCTG == small[i]["TCTG"]:
                print(small[i]["name"])
                boo = False

    if boo:
        print("No match")


#function to count the streak thing
def streak(positions, dna):
    #the main counters
    counter = 0
    maxx = 0

    #to go over all the positions that the str was sited in dna
    for i in range(0, len(positions), 1):
        pIndex = positions[i] #to get that position index in dna
        #to check what type of str it is
        if dna[pIndex] == "A" and dna[pIndex+1] == "G" and dna[pIndex+2] == "A" and dna[pIndex+3] == "T" and dna[pIndex+4] == "C":
            for j in range(positions[i], len(dna), 5): #incrementing by 5 to find sequences
                if dna[j] == "A" and dna[j+1] == "G" and dna[j+2] == "A" and dna[j+3] == "T" and dna[j+4] == "C":
                    counter += 1 #counting the streak
                    if counter > maxx: #updating the longest streak and updating it
                       maxx = counter
                else:
                    counter = 0 #reseting the streak
                    break #existing this sequence and going to the next one

        elif dna[pIndex] == "A" and dna[pIndex+1] == "A" and dna[pIndex+2] == "T" and dna[pIndex+3] == "G":
            for j in range(positions[i], len(dna), 4): #incrementing by 4 to find sequences
                if dna[j] == "A" and dna[j+1] == "A" and dna[j+2] == "T" and dna[j+3] == "G":
                    counter += 1 #counting the streak
                    if counter > maxx: #updating the longest streak and updating it
                        maxx = counter
                else:
                    counter = 0 #reseting the streak
                    break #existing this sequence and going to the next one

        elif dna[pIndex] == "T" and dna[pIndex+1] == "A" and dna[pIndex+2] == "T" and dna[pIndex+3] == "C":
            for j in range(positions[i], len(dna), 4): #incrementing by 4 to find sequences
                if dna[j] == "T" and dna[j+1] == "A" and dna[j+2] == "T" and dna[j+3] == "C":
                    counter += 1 #counting the streak
                    if counter > maxx: #updating the longest streak and updating it
                        maxx = counter

                else:
                    counter = 0 #reseting the streak
                    break #existing this sequence and going to the next one

        elif dna[pIndex] == "G" and dna[pIndex+1] == "A" and dna[pIndex+2] == "T" and dna[pIndex+3] == "A":
            for j in range(positions[i], len(dna), 4): #incrementing by 4 to find sequences
                if dna[j] == "G" and dna[j+1] == "A" and dna[j+2] == "T" and dna[j+3] == "A":
                    counter += 1 #counting the streak
                    if counter > maxx: #updating the longest streak and updating it
                        maxx = counter

                else:
                    counter = 0 #reseting the streak
                    break #existing this sequence and going to the next one

        elif dna[pIndex] == "G" and dna[pIndex+1] == "A" and dna[pIndex+2] == "A" and dna[pIndex+3] == "A":
            for j in range(positions[i], len(dna), 4): #incrementing by 4 to find sequences
                if dna[j] == "G" and dna[j+1] == "A" and dna[j+2] == "A" and dna[j+3] == "A":
                    counter += 1 #counting the streak
                    if counter > maxx: #updating the longest streak and updating it
                        maxx = counter

                else:
                    counter = 0 #reseting the streak
                    break #existing this sequence and going to the next one

        elif dna[pIndex] == "T" and dna[pIndex+1] == "C" and dna[pIndex+2] == "T" and dna[pIndex+3] == "G":
            for j in range(positions[i], len(dna), 4): #incrementing by 4 to find sequences
                if dna[j] == "T" and dna[j+1] == "C" and dna[j+2] == "T" and dna[j+3] == "G":
                    counter += 1 #counting the streak
                    if counter > maxx: #updating the longest streak and updating it
                        maxx = counter

                else:
                    counter = 0 #reseting the streak
                    break #existing this sequence and going to the next one

        elif dna[pIndex] == "T" and dna[pIndex+1] == "C" and dna[pIndex+2] == "T" and dna[pIndex+3] == "A" and dna[pIndex+4] == "G":
            for j in range(positions[i], len(dna), 5): #incrementing by 5 to find sequences
                if dna[j] == "T" and dna[j+1] == "C" and dna[j+2] == "T" and dna[j+3] == "A" and dna[j+4] == "G":
                    counter += 1 #counting the streak
                    if counter > maxx: #updating the longest streak and updating it
                        maxx = counter

                else:
                    counter = 0 #reseting the streak
                    break #existing this sequence and going to the next one

        elif dna[pIndex] == "T" and dna[pIndex+1] == "T" and dna[pIndex+2] == "T" and dna[pIndex+3] == "T" and dna[pIndex+4] == "T" and dna[pIndex+5] == "T" and dna[pIndex+6] == "C" and dna[pIndex+7] == "T":
            for j in range(positions[i], len(dna), 8): #incrementing by 5 to find sequences
                if dna[j] == "T" and dna[j+1] == "T" and dna[j+2] == "T" and dna[j+3] == "T" and dna[j+4] == "T" and dna[j+5] == "T" and dna[j+6] == "C" and dna[j+7] == "T":
                    counter += 1 #counting the streak
                    if counter > maxx: #updating the longest streak and updating it
                        maxx = counter

                else:
                    counter = 0 #reseting the streak
                    break  # existing this sequence and going to the next one

    return maxx #returning the largest sequence or streak what ever you wanna call it


main()